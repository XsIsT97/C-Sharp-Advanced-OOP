﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface ISociety
    {
        public string Id { get; set; }
    }
}